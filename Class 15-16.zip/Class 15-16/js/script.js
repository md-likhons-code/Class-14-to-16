jQuery(document).ready(function() {
    
    $('ul li').click(function() {
        $('ul li').removeClass('active');
        $(this).addClass('active');

        $('.tab-content').hide();

        let tab = $(this).data('tab');

        $(`#${tab}`).slideToggle('slow');
    });
    
    $('.single-img-popup-vartical').magnificPopup({
        type: 'image',
        closeOnContentClick: true,
        image: {
            verticalFit: true
        }
    });

    $('.single-img-popup-fit-width').magnificPopup({
        type: 'image',
        closeOnContentClick: true,
        image: {
            verticalFit: false
        }
    });

    $('.single-img-zoom-popup').magnificPopup({
        type: 'image',
        closeOnContentClick: true,
        closeBtnInside: false,
        fixedContentPos: true,
        image: {
            verticalFit: false
        },
        zoom: {
            enabled: 'true',
            duration: 400
        }
    });

    $('.popup').magnificPopup({
        delegate: 'a',
        type: 'image',
        gallery: {
            enabled: true,
            navigetByImgClik: true
        }
    });

    $('.youtube-video, .google-map').magnificPopup({
		disableOn: 700,
		type: 'iframe',
		mainClass: 'mfp-fade',
		removalDelay: 160,
		preloader: false,
		fixedContentPos: false,

        iframe: {
            patterns: {
              youtube: {
                index: 'youtube.com/',
                id: 'v=',
                src: 'https://www.youtube.com/embed/98FO19TuI9A?si=YgGyzBNPcwa5S_Zn'
              },
              gmaps: {
                index: 'maps.google.com',
                src: 'https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d53678.16238001339!2d90.43378308792119!3d23.73693281993376!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e1!3m2!1sen!2sbd!4v1740027645425!5m2!1sen!2sbd'
              }
            },
            srcAction: 'iframe_src',
          }
	});

    $(".slider").slick({
        autoplay: true,
        autoplaySpeed: 2000,
        dots: true,
        prevArrow: "<span><</span>",
        nextArrow: "<span class='right-arrow'>></span>"
    });

    $(".logo-carousel").slick({
        autoplay: true,
        dots: true,
        arrows: false,
        slidesToShow: 3,
        slidesToScroll: 3
    });

});
