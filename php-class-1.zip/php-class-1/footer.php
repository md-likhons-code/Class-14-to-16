</div>

        <div class="footer">
            <p>Copyright <?php echo date('Y'); ?>, our website.</p>
        </div>
        </div>
    </div>


</body>
</html>