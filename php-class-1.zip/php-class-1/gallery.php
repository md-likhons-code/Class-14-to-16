<?php include_once('header.php'); ?>
    <h3>This is our Bangladesh</h3>
    <div class="img-box">
        <div class="flex-1">
            <div class="single-img-box">
                <img src="images/one.jpg" alt="">
            </div>

            <div class="single-img-box">
                <img src="images/two.jpg" alt="">
            </div>

            <div class="single-img-box">
                <img src="images/three.jpg" alt="">
            </div>
        </div>

        <div class="flex-2">
        <div class="single-img-box">
            <img src="images/images.jpg" alt="">
        </div>

        <div class="single-img-box">
            <img src="images/Beautiful-places-in-Bangladesh-WMC-hero.jpg" alt="">
        </div>
        <div class="single-img-box">
            <img src="images/paharpur-buddhist-monastery.jpg" alt="">
        </div>
        </div>
        
    </div>
    <div class="button">
    <a href="" class="btn">View more</a>
    </div>
<?php include_once('footer.php'); ?>