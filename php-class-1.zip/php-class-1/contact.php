<?php include_once('header.php'); ?>
    <h3>Contact us</h3>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem cumque maxime dolorem voluptatibus mollitia. Nobis veniam laudantium assumenda quos obcaecati debitis dicta repudiandae eum dolorum? Sit amet consectetur adipisicing elit. Autem cumque maxime dolorem voluptatibus mollitia. Nobis veniam laudantium assumenda quos obcaecati debitis dicta repudiandae eum.</p>
    <div class="button">
    <a href="" class="btn">Contact us</a>
    </div>

    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4085.1449651885764!2d90.38805964861287!3d23.73395313462449!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b8e90a449e4f%3A0xb7092a9c25197fa4!2sUniversity%20of%20Dhaka!5e1!3m2!1sen!2sbd!4v1740680807563!5m2!1sen!2sbd" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
<?php include_once('footer.php'); ?>