<?php include_once('header.php'); ?>
    <h3>Suppor</h3>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem cumque maxime dolorem voluptatibus mollitia. Nobis veniam laudantium assumenda quos obcaecati debitis dicta repudiandae eum dolorum? Sit amet consectetur adipisicing elit. Autem cumque maxime dolorem voluptatibus mollitia. Nobis veniam laudantium assumenda quos obcaecati debitis dicta repudiandae eum.quos obcaecati debitis dicta repudiandae eum dolorum? Sit amet consectetur adipisicing elit. Autem cumque maxime dolorem voluptatibus mollitia. Nobis veniam laudantium assumenda quos obcaecati debitis dicta repudiandae eum.quos obcaecati debitis dicta repudiandae eum dolorum? Sit amet consectetur adipisicing elit. Autem cumque maxime dolorem voluptatibus mollitia. Nobis veniam laudantium assumenda quos obcaecati debitis dicta repudiandae eum.</p>
    <div class="button">
    <a href="" class="btn">Help center</a>
    </div>
<?php include_once('footer.php'); ?>