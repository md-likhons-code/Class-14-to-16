<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>website design - solar solution - corporate</title>
    <link rel="stylesheet" href="src/output.css">
</head>
<body>
    
    <header class="bg-black py-8">
        <div class="container">
            <div class="flex justify-between items-center">
                <div class="logo min-w-max cursor-pointer">
                    <img src="img/logo.png" alt="">
                </div>
                <div class="menu">
                    <ul class="flex">
                        <li class="px-4"><a class="text-white block hover:text-red-500 duration-[.3s]" href="">HOME</a></li>
                        <li class="px-4"><a class="text-white block hover:text-red-500 duration-[.3s]" href="">ABOUT US</a></li>
                        <li class="px-4"><a class="text-white block hover:text-red-500 duration-[.3s]" href="">SOLAR INITIATIVES</a></li>
                        <li class="px-4"><a class="text-white block hover:text-red-500 duration-[.3s]" href="">OUR SERVICES</a></li>
                        <li class="px-4"><a class="text-white block hover:text-red-500 duration-[.3s]" href="">COMMUNITY</a></li>
                        <li class="px-4"><a class="text-white block hover:text-red-500 duration-[.3s]" href="">AESTHETICS</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header>

    <div class="hero-area mt-10">
        <div class="container">
            <div style="background-image: url('img/image-20.jpg')" class="bg-center bg-cover bg-no-repeat relative after:absolute after:top-0 after:left-0 after:bg-[linear-gradient(to_left,rgba(0,0,0,0),rgba(0,0,0,1))] after:content-[''] after:w-full after:h-full after:block rounded-xl after:rounded-xl">
                <h1 class="text-white text-[70px] font-bold leading-[76px] w-[700px] uppercase px-10 py-35 tracking-[-1px] relative z-1"><span class="block">Solar</span> <span class="text-red-600">Solutions</span> for a Sustainable Tomorrow<span class="text-red-600">.</span></h1>
            </div>
        </div>
    </div>

    <div class="experience mt-30">
        <div class="container">
            <h1 class="font-bold text-[50px] mb-6">Our Expertise and Experience</h1>
            <div class="flex justify-between">
                <div style="background-image: url('img/img-1.jpg')" class="item-1 w-[23%] h-[430px] bg-cover bg-center bg-no-repeat relative after:absolute after:top-0 after:left-0 after:bg-[linear-gradient(to_top,rgba(0,0,0,0),rgba(0,0,0,.7))] after:content-[''] after:w-full after:h-full after:block rounded-xl after:rounded-xl">
                    <h4 class="text-white font-bold text-[24px] leading-[31px] relative z-1 w-[40%] pt-6 pl-5 mb-4">Solar Solutions</h4>
                    <p class="text-white text-[16px] leading-[22px] px-5 relative z-1">Harness the power of the sun and embrace clean, renewable energy with our solar solutions.</p>
                </div>
                <div style="background-image: url('img/img-2.jpg')" class="item-2 w-[23%] h-[430px] bg-cover bg-center bg-no-repeat relative after:absolute after:top-0 after:left-0 after:bg-[linear-gradient(to_top,rgba(0,0,0,0),rgba(0,0,0,.7))] after:content-[''] after:w-full after:h-full after:block rounded-xl after:rounded-xl">
                    <h4 class="text-white font-bold text-[24px] leading-[31px] relative z-1 w-[40%] pt-6 pl-5 mb-4">Cable Services</h4>
                    <p class="text-white text-[16px] leading-[22px] px-5 relative z-1">Stay connected with high-quality cable services that deliver reliable and fast internet, television</p>
                </div>
                <div style="background-image: url('img/img-3.jpg')" class="item-3 w-[23%] h-[430px] bg-cover bg-center bg-no-repeat relative after:absolute after:top-0 after:left-0 after:bg-[linear-gradient(to_top,rgba(0,0,0,0),rgba(0,0,0,.7))] after:content-[''] after:w-full after:h-full after:block rounded-xl after:rounded-xl">
                    <h4 class="text-white font-bold text-[24px] leading-[31px] relative z-1 w-[40%] pt-6 pl-5 mb-4">Internet Solutions</h4>
                    <p class="text-white text-[16px] leading-[22px] px-5 relative z-1">From fast broadband to fiber-optic connections, we'll help you find the internet service provider</p>
                </div>
                <div style="background-image: url('img/img-4.jpg')" class="item-4 w-[23%] h-[430px] bg-cover bg-center bg-no-repeat relative after:absolute after:top-0 after:left-0 after:bg-[linear-gradient(to_top,rgba(0,0,0,0),rgba(0,0,0,.7))] after:content-[''] after:w-full after:h-full after:block rounded-xl after:rounded-xl">
                    <h4 class="text-white font-bold text-[24px] leading-[31px] relative z-1 w-[40%] pt-6 pl-5 mb-4">Phone Services</h4>
                    <p class="text-white text-[16px] leading-[22px] px-5 relative z-1">Discover cost-effective and feature-rich phone services that keep you connected to your loved ones</p>
                </div>
            </div>
        </div>
    </div>


    <div class="aedthetics bg-[#F4F4F4] mt-20 py-20">
        <div class="container">
            <div class="flex justify-between items-center pb-5">
                <div class="single-item w-[32%] p-10">
                    <h2 class="font-bold text-[50px] leading-[67px] mb-3">Why Choose Us?</h2>
                    <p class="text-[18px] leading-[22px]">Whether you're looking to switch to solar energy or upgrade your cable services, our sales and marketing company is here to help.</p>
                </div>
                <div class="single-item bg-white w-[32%] p-10 rounded-xl">
                    <h2 class="text-red-500 font-bold text-[58px]">01</h2>
                    <h4 class="text-[#5C5C5C] text-[24px] font-bold mb-2">Expertise and Experience</h4>
                    <p class="text-[#787878] text-[18px] leading-[23px]">With years of experience in the sales and marketing industry, our team has a deep</p>
                </div>
                <div class="single-item bg-red-600 w-[32%] p-10  rounded-xl">
                    <h2 class="text-white font-bold text-[58px]">02</h2>
                    <h4 class="text-white text-[24px] font-bold mb-2">Extensive Network</h4>
                    <p class="text-white text-[18px] leading-[23px]">We have established strong relationships with the leading solar and cable companies in the region</p>
                </div>
            </div>
            <div class="flex justify-between items-center">
                <div class="single-item bg-white w-[32%] p-10 rounded-xl">
                    <h2 class="text-red-500 font-bold text-[58px]">03</h2>
                    <h4 class="text-[#5C5C5C] text-[24px] font-bold mb-2">Personalized Approach</h4>
                    <p class="text-[#787878] text-[18px] leading-[23px]">We believe that every customer is unique, and their needs should be addressed accordingly</p>
                </div>
                <div class="single-item bg-white w-[32%] p-10 pb-5 rounded-xl">
                    <h2 class="text-red-500 font-bold text-[58px]">04</h2>
                    <h4 class="text-[#5C5C5C] text-[24px] font-bold mb-2">Cost Savings</h4>
                    <p class="text-[#787878] text-[18px] leading-[23px]">By leveraging our industry knowledge and network, we can help you save money on your solar and cable purchases</p>
                </div>
                <div class="single-item bg-white w-[32%] p-10 rounded-xl">
                    <h2 class="text-red-500 font-bold text-[58px]">05</h2>
                    <h4 class="text-[#5C5C5C] text-[24px] font-bold mb-2">Hassle-Free Process</h4>
                    <p class="text-[#787878] text-[18px] leading-[23px]">We handle all the research, negotiations, and paperwork for you, making the process of finding</p>
                </div>
            </div>
        </div>
    </div>

    <div class="community bg-red-600 py-10">
        <div class="container">
            <div class="flex justify-between items-center">
                <div class="w-[47%]">
                    <h2 class="text-white font-bold text-[50px] mb-2">Who We Are</h2>
                    <p class="text-white text-[19px] leading-[30px] mb-7">Welcome to our sales and marketing company, where we specialize in helping customers snag great deals from the leading solar and cable companies in the DC, Maryland, and Virginia area.We understand that finding the right solar and cable solutions for your needs can be a daunting task, which is why we're here to make the process easier and more affordable for you.</p>
                    <a href="" class="text-black bg-white text-[18px] px-6 py-2 rounded-3xl inline-block mr-3">Read More</a>
                    <a href="" class="text-white bg-black text-[18px] px-6 py-2 rounded-3xl inline-block">Contact us today</a>
                </div>
                <div class="w-[47%] flex justify-end">
                    <div class="w-6/12">
                        <img src="img/photo-2.jpg" alt="">
                    </div>
                    <div class="w-6/12 mt-18 -ml-25">
                        <img src="img/photo-1.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="service my-30">
        <div class="container">
            <div class="text-center mb-3">
                <h4 class="text-red-600 text-[20px] font-bold">Our Services</h4>
                <h2 class="text-black font-bold text-[50px]">What We Do</h2>
            </div>
            <div class="flex justify-between items-center">
                <div class="w-[33%]">
                    <div class="bg-[#F3F3F3] p-7 pr-15 mb-7 rounded-2xl">
                        <div class="w-[12%] mb-2">
                            <img src="img/mask-1.png" alt="">
                        </div>
                        <h3 class="text-[#464646] font-bold text-[24px] mb-2">Solar Solutions</h3>
                        <p class="text-[#787878] text-[18px] leading-[25px]">Harness the power of the sun and embrace clean, renewable energy with our solar solutions.</p>
                    </div>
                    <div class="bg-[#F3F3F3] p-7 pr-15 rounded-2xl">
                        <div class="w-[12%] mb-2">
                            <img src="img/mask-2.png" alt="">
                        </div>
                        <h3 class="text-[#464646] font-bold text-[24px] mb-2">Cable Services</h3>
                        <p class="text-[#787878] text-[18px] leading-[25px]">Stay connected with high-quality cable services that deliver reliable and fast internet, television</p>
                    </div>
                </div>
                <div class="w-[25%]">
                    <img src="img/main.jpg" alt="">
                </div>
                <div class="w-[33%]">
                    <div class="bg-[#F3F3F3] p-7 pr-15 mb-7 rounded-2xl">
                        <div class="w-[12%] mb-2">
                            <img src="img/mask-3.png" alt="">
                        </div>
                        <h3 class="text-[#464646] font-bold text-[24px] mb-2">Deals and Promotions</h3>
                        <p class="text-[#787878] text-[18px] leading-[25px]">We pride ourselves on securing great deals and promotions for our customers.</p>
                    </div>
                    <div class="bg-[#F3F3F3] p-7 pr-15 rounded-2xl">
                        <div class="w-[12%] mb-2">
                            <img src="img/mask-4.png" alt="">
                        </div>
                        <h3 class="text-[#464646] font-bold text-[24px] mb-2">Consultation and Support</h3>
                        <p class="text-[#787878] text-[18px] leading-[25px] pb-1">We understand that navigating the solar and cable landscape can be overwhelming.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="bg-black text-white">
        <div class=" border-gray-800 border-b">
            <div class="container">
                <div class="title py-10">
                    <p class="text-[18px] leading-[31px]">
                    Whether you're looking to switch to solar energy or upgrade your cable services, our sales and marketing company is here to help. Contact us today to start saving on your energy bills and enjoy reliable connectivity from the leading solar and cable companies in the DC, Maryland, and Virginia area. Snag the best deals with us and embrace a brighter and more connected future.
                    </p>
                </div>
            </div>
        </div>

        <div class="my-5">
            <div class="container py-14">
                <div class="flex -mx-6">
                    <div class="w-[28%] px-6 border-gray-800 border-r">
                        <div class="min-w-max mb-5">
                            <img src="img/logo.png" alt="">
                        </div>
                        <p class="text-[16px] leading-[27px]">
                        Contact us today to explore our services and take advantage of the great deals available from the leading solar and cable companies in the DC, Maryland, and Virginia area. Let us be your trusted partner in finding the best solutions for your energy and connectivity needs.
                        </p>
                    </div>
                    <div class="w-[24%] px-6 pt-10 border-gray-800 border-r">
                        <h4 class="text-[16px] mb-5">Quick Links</h4>
                        <ul class="leading-8">
                            <li><a class="hover:text-red-500 duration-[.3s]" href="">Home</a></li>
                            <li><a class="hover:text-red-500 duration-[.3s]" href="">About Us</a></li>
                            <li><a class="hover:text-red-500 duration-[.3s]" href="">Solar Initiatives</a></li>
                            <li><a class="hover:text-red-500 duration-[.3s]" href="">Our Services</a></li>
                            <li><a class="hover:text-red-500 duration-[.3s]" href="">Community</a></li>
                            <li><a class="hover:text-red-500 duration-[.3s]" href="">Aesthetics</a></li>
                        </ul>
                    </div>
                    <div class="w-[24%] px-6 pt-10 border-gray-800 border-r">
                        <h4 class="text-[16px] mb-5">Services</h4>
                        <ul class="leading-8">
                            <li><a class="hover:text-red-500 duration-[.3s]" href="">Solar Solution</a></li>
                            <li><a class="hover:text-red-500 duration-[.3s]" href="">Cable Services</a></li>
                            <li><a class="hover:text-red-500 duration-[.3s]" href="">Deals and Promotions</a></li>
                            <li><a class="hover:text-red-500 duration-[.3s]" href="">Consultation and Suppor</a></li>
                        </ul>
                    </div>
                    <div class="w-[24%] px-6 pt-10">
                        <h4 class="text-[16px] mb-5">Contact</h4>
                        <div class="flex mb-2">
                            <div class="icon mr-3">
                                <img src="img/phone.png" alt="">
                            </div>
                            <p>0123456789</p>
                        </div>
                        <div class="flex mb-3">
                            <div class="icon mr-3">
                                <img src="img/mail.png" alt="">
                            </div>
                            <p>companyname@gmail.com</p>
                        </div>
                        <div class="flex items-center">
                            <a class="hover:text-red-500 duration-[.3s]" href=""><img class="mr-3" src="img/fb.png" alt=""></a>
                            <a href=""><img class="mr-3" src="img/tw.png" alt=""></a>
                            <a href=""><img src="img/ins.png" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            
        
        <div class="border-gray-800 border-t py-5">
            <div class="container">
                <p class="text-center">© 2023 Company Name  -  developed by Roots Digital Marketing</p>
            </div>
        </div>
    </footer>

</body>
</html>